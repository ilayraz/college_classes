// Ilay Raz
// ilraz
// CMPS12B-02
// 2/23/18
// QueueEmptyException.java

public class QueueEmptyException extends RuntimeException {
    public QueueEmptyException(String s) {
        super(s);
    }
}
