// Ilay Raz
// ilraz
// CMPS12B-02
// 2/6/18
// DuplicateKeyException.java

public class DuplicateKeyException extends RuntimeException {
    public DuplicateKeyException(String s) {
        super(s);
    }
}
