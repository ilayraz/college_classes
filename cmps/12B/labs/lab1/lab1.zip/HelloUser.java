/*
Ilay Raz
1573848
CMPS12M-02
1/15/18
HelloUser.java
*/

class HelloUser {
    public static void main(String[] args) {
        System.out.println("HelloUser.main()");
    }
}
