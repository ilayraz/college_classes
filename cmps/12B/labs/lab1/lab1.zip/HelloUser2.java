/*
Ilay Raz
1573848
CMPS12M-02
1/15/18
HelloUser2.java
*/

class HelloUser2 {
    public static void main(String[] args) {
        System.out.println("HelloUser2.main()");
    }
}
